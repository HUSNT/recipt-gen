# amethyx
amethyx source code

fuck you don't ask me on how to use it
